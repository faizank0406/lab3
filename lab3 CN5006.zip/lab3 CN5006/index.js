console.log("THIS IS CN5006 MODULE")
console.log("Well come jhon your month salary is 50000")

//Example 2(addition)
const num1 = 10;
const num2 = 20;

//add two numbers

const sum = num1 + num2;

//display the sum

console.log('THE SUM OF ' +  num1 + ' and ' + num2 + ' is :' +sum );

//Program that check subtraction of two numbers

const first = 200;
const second= 20;

//add two numbers

const sub = first - second;

//display the sub

console.log('THE SUB OF ' + num1 + ' and ' + num2 + ' is :' +sub);

// Program that check multiplication of 3 numbers

const A = 13;
const B = 2;
const C = 12;

//add 3 numbers

const mul = A*B*C;

//dipslay the multiplication of 3 numbers

console.log('THE MUL OF ' + A + ' and ' + B + ' and ' + C +' is :' + mul);

//Program that check Division of two numbers

const one = 200;
const two = 20;

//add two numbers

const div = one % two;

//display the div

console.log('THE DIV OF ' + one + ' and ' + two + ' is :' + div);




// program that checks if the number is positive, negative or zero 
// input from the user 
const prompt = reqqire ('prompt-sync')();

const number = parseInt(prompt("Enter a number: ")); 
// check if number is greater than 0 
if (number > 0) { 
console.log("The number is positive"); 
} 
// check if number is 0 
else if (number == 0) { 
console.log("The number is zero"); 
} 
// if number is less than 0 
else { 
console.log("The number is negative"); 
} 

const { Console } = require('console');
const os = require('os');
const myutil = require('util'); 

// defination of the function EmployeeInfo
function EmployeeInfo(name,salary)
{
    console.log(" Wellcome " + name + "  Your monthley salary is  " + salary)
}

console.log("This is my first Progame")

var EmpName=" Zoya "
var EmpSalary= 10000;

//calling of the function EmployeeInfo

EmployeeInfo(EmpName,EmpSalary);

const EmpSkills= (skills) => {
    console.log("Expert in " + skills)
}

EmpSkills("java")

const student = require('./Studenfile')
const person = require('./person')


//because gegtName is the function so we use ()

console.log("Student Name:" + student.getName())
console.log(student.Location())
console.log(student.dob)

//because dob is a variable so we do nt use()

console.log(student.Studentgrade())
console.log("grade is " + student.Studentgrade(55))

//creating new person

person1 = new person("jim","USA","myemail@gmail.com")
console.log("using person module", person1.getPersonInfo())

console.log("program ended")

os = require("os")
const util = require('util')
console.log("temporary Directory: " +os.tmpdir);
Console.log("hostname: " + os.hostname());
Console.log("Os:" +  os.platform() + ", Release: "+ os.release());
console.log("uptime: " + (os.uptime()/ 3600) +" hours");
Console.log("UserInfo:" +util.inspect(os.userInfo()));
Console.log("Memory:" + (os.totalmem()/ 1e9) + "GB");
Console.log("Free:" + (os.freemem()/ 1e9) + "GB");
console.log("CPU Info:" +util.inspect(os.cpus()));
console.log("Network Interface:" + util.inspect(os.networkInterfaces()));

